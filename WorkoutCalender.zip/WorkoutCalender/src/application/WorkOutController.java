package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class WorkOutController<LocalEvent> {
    public void initialize(URL url, ResourceBundle rb){
        DatePicker.setValue(LocalDate.now());

    }
    @FXML
    private DatePicker connectDate;

    @FXML
    ListView<LocalEvent> eventList;

    @FXML
    TextField descriptionTextField;

    @FXML
    Button addButton;

    @FXML
    private void addEvent(Event e) {
        list.add(new LocalEvent(datePicker.getValue().descriptionTextField.getText));
        eventList.setItems(eventList);

    }

    public void ShowDate(ActionEvent actionEvent) {
        LocalDate id = connectDate.getValue();
        addButton.setText(id.toString());
    }

}
