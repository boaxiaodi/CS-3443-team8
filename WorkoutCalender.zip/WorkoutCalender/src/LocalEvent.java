import java.time.LocalDate;
public class LocalEvent {
    public LocalEvent(String description) {
        this.description = description;
    }

    private String description;
    private LocalDate date;

    public LocalEvent(LocalDate date) {
        this.date = date;
    }
    public LocalEvent(LocalDate date, String description){
        this.setDate(date);
        this.setDescription(description);
    }

    private void setDescription(String description) {
    }

    private void setDate(LocalDate date) {
    }
}
